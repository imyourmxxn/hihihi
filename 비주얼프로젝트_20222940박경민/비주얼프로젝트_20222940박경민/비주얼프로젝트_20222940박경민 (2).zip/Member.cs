﻿//회원 정보 폼에 회원 정보 저장하는 기능 구현
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 비주얼프로젝트_20222940박경민
{
    public class Member
        {
            public string Name { get; set; }
            public string Birth { get; set; }
            public string Tel { get; set; }
            public string Gender { get; set; }
        }
    }

