﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace 비주얼프로젝트_20222940박경민
{
    public partial class Form1 : 비주얼프로젝트_20222940박경민.MemManage
    {
        Mem
        public Form1()
        {
            InitializeComponent();
        }
    }
}
