﻿namespace 비주얼프로젝트_20222940박경민
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MainBox = new System.Windows.Forms.GroupBox();
            this.btnConnectMemo = new System.Windows.Forms.Button();
            this.btnConnectInbody = new System.Windows.Forms.Button();
            this.btnConectGoodsManage = new System.Windows.Forms.Button();
            this.btnConnectWrite = new System.Windows.Forms.Button();
            this.btnConectMemManage = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.MainBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainBox
            // 
            this.MainBox.Controls.Add(this.label5);
            this.MainBox.Controls.Add(this.label4);
            this.MainBox.Controls.Add(this.label3);
            this.MainBox.Controls.Add(this.label2);
            this.MainBox.Controls.Add(this.label1);
            this.MainBox.Controls.Add(this.btnConnectMemo);
            this.MainBox.Controls.Add(this.btnConnectInbody);
            this.MainBox.Controls.Add(this.btnConectGoodsManage);
            this.MainBox.Controls.Add(this.btnConnectWrite);
            this.MainBox.Controls.Add(this.btnConectMemManage);
            this.MainBox.Location = new System.Drawing.Point(26, 12);
            this.MainBox.Name = "MainBox";
            this.MainBox.Size = new System.Drawing.Size(746, 413);
            this.MainBox.TabIndex = 0;
            this.MainBox.TabStop = false;
            this.MainBox.Text = "🏋헬스장 관리 프로그램🏋";
            this.MainBox.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnConnectMemo
            // 
            this.btnConnectMemo.Image = global::비주얼프로젝트_20222940박경민.Properties.Resources.공부;
            this.btnConnectMemo.Location = new System.Drawing.Point(492, 52);
            this.btnConnectMemo.Name = "btnConnectMemo";
            this.btnConnectMemo.Size = new System.Drawing.Size(136, 141);
            this.btnConnectMemo.TabIndex = 4;
            this.btnConnectMemo.UseVisualStyleBackColor = true;
            this.btnConnectMemo.Click += new System.EventHandler(this.btnConnectMemo_Click);
            // 
            // btnConnectInbody
            // 
            this.btnConnectInbody.Image = global::비주얼프로젝트_20222940박경민.Properties.Resources.운동2;
            this.btnConnectInbody.Location = new System.Drawing.Point(400, 225);
            this.btnConnectInbody.Name = "btnConnectInbody";
            this.btnConnectInbody.Size = new System.Drawing.Size(136, 141);
            this.btnConnectInbody.TabIndex = 3;
            this.btnConnectInbody.UseVisualStyleBackColor = true;
            this.btnConnectInbody.Click += new System.EventHandler(this.btnConnectInbody_Click);
            // 
            // btnConectGoodsManage
            // 
            this.btnConectGoodsManage.Image = global::비주얼프로젝트_20222940박경민.Properties.Resources.운동3;
            this.btnConectGoodsManage.Location = new System.Drawing.Point(311, 53);
            this.btnConectGoodsManage.Name = "btnConectGoodsManage";
            this.btnConectGoodsManage.Size = new System.Drawing.Size(136, 141);
            this.btnConectGoodsManage.TabIndex = 2;
            this.btnConectGoodsManage.UseVisualStyleBackColor = true;
            this.btnConectGoodsManage.Click += new System.EventHandler(this.btnConectGoodsManage_Click);
            // 
            // btnConnectWrite
            // 
            this.btnConnectWrite.Image = global::비주얼프로젝트_20222940박경민.Properties.Resources.게시판;
            this.btnConnectWrite.Location = new System.Drawing.Point(213, 225);
            this.btnConnectWrite.Name = "btnConnectWrite";
            this.btnConnectWrite.Size = new System.Drawing.Size(136, 141);
            this.btnConnectWrite.TabIndex = 1;
            this.btnConnectWrite.UseVisualStyleBackColor = true;
            this.btnConnectWrite.Click += new System.EventHandler(this.btnConnectWrite_Click);
            // 
            // btnConectMemManage
            // 
            this.btnConectMemManage.Image = global::비주얼프로젝트_20222940박경민.Properties.Resources.운동;
            this.btnConectMemManage.Location = new System.Drawing.Point(127, 52);
            this.btnConectMemManage.Name = "btnConectMemManage";
            this.btnConectMemManage.Size = new System.Drawing.Size(136, 141);
            this.btnConectMemManage.TabIndex = 0;
            this.btnConectMemManage.UseVisualStyleBackColor = true;
            this.btnConectMemManage.Click += new System.EventHandler(this.btnConectMemManage_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(340, 197);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "기구현황관리";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(524, 196);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "개인메모관리";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(254, 369);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "게시판관리";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(421, 369);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "인바디기록관리";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(167, 196);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 9;
            this.label5.Text = "회원관리";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MainBox);
            this.Name = "Main";
            this.Text = "         /";
            this.MainBox.ResumeLayout(false);
            this.MainBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox MainBox;
        private System.Windows.Forms.Button btnConnectMemo;
        private System.Windows.Forms.Button btnConnectInbody;
        private System.Windows.Forms.Button btnConectGoodsManage;
        private System.Windows.Forms.Button btnConnectWrite;
        private System.Windows.Forms.Button btnConectMemManage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}