﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 비주얼프로젝트_20222940박경민
{
    public class Inbody
    {
        public string InbodyDate { get; set; }
        public string InbodyWeight{get; set; }
        public string InbodyMuscle { get; set; }
        public string InbodyFat { get; set; }
        public string InbodyBmi { get; set; }
        public string InbodyFatRate { get; set; }
    }
}
