﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 비주얼프로젝트_20222940박경민
{
    public class Memo
    {
        public string MemoDate { get; set; }
        public string MemoContext { get; set; }
    }
}
