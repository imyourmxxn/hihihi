﻿namespace 비주얼프로젝트_20222940박경민
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MainBox = new System.Windows.Forms.GroupBox();
            this.btnConnectMemo = new System.Windows.Forms.Button();
            this.btnConnectInbody = new System.Windows.Forms.Button();
            this.btnConectGoodsManage = new System.Windows.Forms.Button();
            this.btnConnectWrite = new System.Windows.Forms.Button();
            this.btnConectMemManage = new System.Windows.Forms.Button();
            this.MainBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainBox
            // 
            this.MainBox.Controls.Add(this.btnConnectMemo);
            this.MainBox.Controls.Add(this.btnConnectInbody);
            this.MainBox.Controls.Add(this.btnConectGoodsManage);
            this.MainBox.Controls.Add(this.btnConnectWrite);
            this.MainBox.Controls.Add(this.btnConectMemManage);
            this.MainBox.Location = new System.Drawing.Point(80, 104);
            this.MainBox.Name = "MainBox";
            this.MainBox.Size = new System.Drawing.Size(606, 282);
            this.MainBox.TabIndex = 0;
            this.MainBox.TabStop = false;
            this.MainBox.Text = "🏋헬스장 관리 프로그램🏋";
            this.MainBox.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnConnectMemo
            // 
            this.btnConnectMemo.Location = new System.Drawing.Point(431, 46);
            this.btnConnectMemo.Name = "btnConnectMemo";
            this.btnConnectMemo.Size = new System.Drawing.Size(114, 82);
            this.btnConnectMemo.TabIndex = 4;
            this.btnConnectMemo.Text = "개인메모관리";
            this.btnConnectMemo.UseVisualStyleBackColor = true;
            this.btnConnectMemo.Click += new System.EventHandler(this.btnConnectMemo_Click);
            // 
            // btnConnectInbody
            // 
            this.btnConnectInbody.Location = new System.Drawing.Point(252, 156);
            this.btnConnectInbody.Name = "btnConnectInbody";
            this.btnConnectInbody.Size = new System.Drawing.Size(114, 83);
            this.btnConnectInbody.TabIndex = 3;
            this.btnConnectInbody.Text = "인바디기록관리";
            this.btnConnectInbody.UseVisualStyleBackColor = true;
            this.btnConnectInbody.Click += new System.EventHandler(this.btnConnectInbody_Click);
            // 
            // btnConectGoodsManage
            // 
            this.btnConectGoodsManage.Location = new System.Drawing.Point(252, 47);
            this.btnConectGoodsManage.Name = "btnConectGoodsManage";
            this.btnConectGoodsManage.Size = new System.Drawing.Size(114, 82);
            this.btnConectGoodsManage.TabIndex = 2;
            this.btnConectGoodsManage.Text = "기구 현황 관리";
            this.btnConectGoodsManage.UseVisualStyleBackColor = true;
            this.btnConectGoodsManage.Click += new System.EventHandler(this.btnConectGoodsManage_Click);
            // 
            // btnConnectWrite
            // 
            this.btnConnectWrite.Location = new System.Drawing.Point(68, 157);
            this.btnConnectWrite.Name = "btnConnectWrite";
            this.btnConnectWrite.Size = new System.Drawing.Size(114, 82);
            this.btnConnectWrite.TabIndex = 1;
            this.btnConnectWrite.Text = "게시판관리";
            this.btnConnectWrite.UseVisualStyleBackColor = true;
            this.btnConnectWrite.Click += new System.EventHandler(this.btnConnectWrite_Click);
            // 
            // btnConectMemManage
            // 
            this.btnConectMemManage.Location = new System.Drawing.Point(68, 46);
            this.btnConectMemManage.Name = "btnConectMemManage";
            this.btnConectMemManage.Size = new System.Drawing.Size(114, 83);
            this.btnConectMemManage.TabIndex = 0;
            this.btnConectMemManage.Text = "회원 관리";
            this.btnConectMemManage.UseVisualStyleBackColor = true;
            this.btnConectMemManage.Click += new System.EventHandler(this.btnConectMemManage_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MainBox);
            this.Name = "Main";
            this.Text = "         /";
            this.MainBox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox MainBox;
        private System.Windows.Forms.Button btnConnectMemo;
        private System.Windows.Forms.Button btnConnectInbody;
        private System.Windows.Forms.Button btnConectGoodsManage;
        private System.Windows.Forms.Button btnConnectWrite;
        private System.Windows.Forms.Button btnConectMemManage;
    }
}