﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 비주얼프로젝트_20222940박경민
{
    public partial class MemManage : Form
    {
        public MemManage()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMemAdd_Click(object sender, EventArgs e)
        {

        }

        private void btnMemSearch_Click(object sender, EventArgs e)
        {

        }

        private void btnMemdelete_Click(object sender, EventArgs e)
        {

        }

        private void btnMemFix_Click(object sender, EventArgs e)
        {

        }
    }
}
