﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 비주얼프로젝트_20222940박경민
{
        public class Goods
        {
            public string GoodsName { get; set; }
            public string GoodsNum { get; set; }
            public string GoodsStatue { get; set; }
        }
}
