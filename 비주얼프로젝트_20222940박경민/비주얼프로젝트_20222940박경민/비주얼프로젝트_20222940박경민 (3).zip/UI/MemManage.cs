﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace 비주얼프로젝트_20222940박경민
{
    public partial class MemManage : Form
    {
        //public MemManage()
        Member mem = new Member();
        const string fname = "memdata.csv";

        public MemManage()
        {
            InitializeComponent();
        }

        public void formClear()
        {
            txtName.Clear(); //이름 입력 후 공백처리
            txtBirth.Clear(); //생년월일 입력 후 공백처리
            txtTel.Clear();   //전화번호 입력 후 공백처리
            txtGender.Clear(); //성별 입력 후 공백처리
            txtName.Focus();   //커서를 Name 텍스트박스로 설정
        }

        public void AddMember(Member mem) //멤버 추가하는 함수
        {
            string[] sitems = new string[] {mem.Name, mem.Birth, mem.Tel, mem.Gender };
            //ListViewItem 객체 생성
            ListViewItem Ivi=new ListViewItem(sitems);
            listView1.Items.Add(Ivi); //데이터 등록
            listView1.EndUpdate(); //리스트뷰 종료 선언
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                txtName.Text = listView1.SelectedItems[0].SubItems[0].Text;
                txtBirth.Text = listView1.SelectedItems[0].SubItems[1].Text;
                txtTel.Text = listView1.SelectedItems[0].SubItems[2].Text;
                txtGender.Text = listView1.SelectedItems[0].SubItems[3].Text;
            }
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMemAdd_Click(object sender, EventArgs e)
        {
            listView1.BeginUpdate(); //listview 업데이트 선업
            mem.Name = txtName.Text.ToString();
            mem.Birth = txtBirth.Text.ToString();
            mem.Tel = txtTel.Text.ToString();
            mem.Gender = txtGender.Text.ToString();
            AddMember(mem);
            formClear(); //입력 부분 공백으로 싹 다 초기화 시키기

        }

        //private void btnMemSearch_Click(object sender, EventArgs e)//회원정보검색
        //{

        //}

        private void btnMemdelete_Click(object sender, EventArgs e)//회원정보삭제
        {
            if (listView1.SelectedItems.Count > 0)//listView1의 항목중 하나가 선택되면
            {
                listView1.Items.Remove(listView1.SelectedItems[0]); //해당 정보 삭제
            }
        }

        private void btnMemFix_Click(object sender, EventArgs e) //회원정보수정
        {
            if (listView1.SelectedItems.Count > 0)
            {
                listView1.SelectedItems[0].SubItems[0].Text = txtName.Text;
                listView1.SelectedItems[0].SubItems[1].Text = txtBirth.Text;
                listView1.SelectedItems[0].SubItems[2].Text = txtTel.Text;
                listView1.SelectedItems[0].SubItems[3].Text = txtGender.Text;
            }
        }

        private void txtGender_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnFileSave_Click(object sender, EventArgs e)
        {
            FileStream fs = File.Create(fname);
            StreamWriter sw = new StreamWriter(fs);

            foreach(ListViewItem lvi in listView1.Items)
            {
                mem.Name = lvi.SubItems[0].Text;
                mem.Birth= lvi.SubItems[1].Text;
                mem.Tel= lvi.SubItems[2].Text;
                mem.Gender= lvi.SubItems[3].Text;
                sw.WriteLine("{0}, {1}, {2}", mem.Name, mem.Birth, mem.Tel, mem.Gender);
            }
            sw.Close();
            fs.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close(); //화면 닫기 문법
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }

}
