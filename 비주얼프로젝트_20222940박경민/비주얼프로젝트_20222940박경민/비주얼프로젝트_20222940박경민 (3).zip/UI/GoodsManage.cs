﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace 비주얼프로젝트_20222940박경민
{
    public partial class GoodsManage : Form
    {
        Goods goods = new Goods();

        public GoodsManage()
        {
            InitializeComponent();
        }

        public void formClear()
        {
            txtGoodsName.Clear(); //기구명 입력 후 공백처리
            txtGoodsNum.Clear(); //기구 갯수 입력 후 공백처리
            txtGoodsStatue.Clear();   //기구 상태 입력 후 공백처리
            txtGoodsName.Focus();   //커서를 Name 텍스트박스로 설정
        }

        public void AddGoods(Goods goods) //멤버 추가하는 함수
        {
            string[] sitems = new string[] { goods.GoodsName, goods.GoodsNum, goods.GoodsStatue };
            //ListViewItem 객체 생성
            ListViewItem Ivi = new ListViewItem(sitems);
            listView1.Items.Add(Ivi); //데이터 등록
            listView1.EndUpdate(); //리스트뷰 종료 선언
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                txtGoodsName.Text = listView1.SelectedItems[0].SubItems[0].Text;
                txtGoodsNum.Text = listView1.SelectedItems[0].SubItems[1].Text;
                txtGoodsStatue.Text = listView1.SelectedItems[0].SubItems[2].Text;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnGoodsFix_Click(object sender, EventArgs e)//기구 정보 수정
        {
            if (listView1.SelectedItems.Count > 0)  //listview에서 항목이 하나 이상 선택되면
            {
                listView1.SelectedItems[0].SubItems[0].Text = txtGoodsName.Text; //기구명 입력 칸 수정 가능
                listView1.SelectedItems[0].SubItems[1].Text = txtGoodsNum.Text;  //기구 갯수 입력 칸 수정 가능
                listView1.SelectedItems[0].SubItems[2].Text = txtGoodsStatue.Text; //기구 상태 입력 칸 수정 가능
            }
        }

        private void btnGoodsClear_Click(object sender, EventArgs e) //기구 정보 삭제
            {
                if (listView1.SelectedItems.Count > 0)//listView1의 항목중 하나가 선택되면
                {
                    listView1.Items.Remove(listView1.SelectedItems[0]); //해당 정보 삭제 기능
                }
            }

            private void btnGoodsSave_Click(object sender, EventArgs e)
            {

            }

            private void btnGoodsClose_Click(object sender, EventArgs e) //창닫기 버튼
            {
                this.Close();
            }

            private void btnEnter_Click(object sender, EventArgs e)//기구 정보 리스트뷰에 등록
            {
                listView1.BeginUpdate(); //listview 업데이트 선업
                goods.GoodsName = txtGoodsName.Text.ToString();
                goods.GoodsNum = txtGoodsNum.Text.ToString();
                goods.GoodsStatue = txtGoodsStatue.Text.ToString();
                AddGoods(goods);
                formClear(); //입력 부분 공백으로 싹 다 초기화 시키기
            }

            private void txtGoodsName_TextChanged(object sender, EventArgs e)
            {

            }

            private void txtGoodsNum_TextChanged(object sender, EventArgs e)
            {

            }

            private void txtGoodsStatue_TextChanged(object sender, EventArgs e)
            {

            }
        }
    }
